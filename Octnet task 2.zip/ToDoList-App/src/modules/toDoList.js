class ToDoList {
  constructor(index, desc, comp) {
    this.index = index;
    this.desc = desc;
    this.comp = comp;
  }
}

export default ToDoList;
